TO THE PEOPLE  SAYING THESE ARE FAKE AND WILL GET YOU BANNED READ BELOW:

🌟PLEASE STAR THIS PROJECT🌟

Join the Discord for support: https://discord.gg/lunaz

if you get banned this is not my issue, as these are against Blooket's TOS

-lol-jude

# DO NOT STEAL MY WORK!

I am in the process of taking legal action against someone stealing my code and posting it as their own. They modified my code as well as deleted all credit towards me. Do not steal my work as I will take legal actions.

# Blooket Info

🌟PLEASE STAR THIS PROJECT🌟

Top 6 list of most popular/used codes...

Add Daily Tokens

ADD Daily Tokens This code will add 500 tokens which is the max daily limit and add the max xp which is 300 daily limit! 

Get Gold

Get Gold code will let you chose any amount of gold you want in the gold quest gamemode you can even get negative gold but not reccomended! 

Chest ESP

Chest ESP Works in multiple gamemodes works best in gold quest once you use this code you wil be able to see what you will get in the chest before even clicking on it so it is very usefull!

Get Crypto

The Get Crypto code is just like the Get gold code but only works in Crypto hack Gamemode. 

5.Get other users password 5. The get other users password code is slightly different to most of the other codes but when you are playing in the crypto hack gamemode and get the hack option in one of the chests use the code and it will tell you your victims password! 

Instant Win
Instant win code will automatically make you win in the racing mode.
There you go!

All codes still working!
